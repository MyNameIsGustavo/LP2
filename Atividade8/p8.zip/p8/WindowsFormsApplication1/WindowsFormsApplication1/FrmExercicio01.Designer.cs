﻿namespace WindowsFormsApplication1
{
    partial class FrmExercicio01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUm = new System.Windows.Forms.Button();
            this.btnDois = new System.Windows.Forms.Button();
            this.btnTres = new System.Windows.Forms.Button();
            this.rtbPrincipal = new System.Windows.Forms.RichTextBox();
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnUm
            // 
            this.btnUm.Location = new System.Drawing.Point(18, 182);
            this.btnUm.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnUm.Name = "btnUm";
            this.btnUm.Size = new System.Drawing.Size(372, 37);
            this.btnUm.TabIndex = 0;
            this.btnUm.Text = "Numeros de espaços em branco";
            this.btnUm.UseVisualStyleBackColor = true;
            this.btnUm.Click += new System.EventHandler(this.btnUm_Click);
            // 
            // btnDois
            // 
            this.btnDois.Location = new System.Drawing.Point(18, 229);
            this.btnDois.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnDois.Name = "btnDois";
            this.btnDois.Size = new System.Drawing.Size(372, 37);
            this.btnDois.TabIndex = 1;
            this.btnDois.Text = "Quantidade de R na frase";
            this.btnDois.UseVisualStyleBackColor = true;
            // 
            // btnTres
            // 
            this.btnTres.Location = new System.Drawing.Point(18, 276);
            this.btnTres.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnTres.Name = "btnTres";
            this.btnTres.Size = new System.Drawing.Size(372, 37);
            this.btnTres.TabIndex = 2;
            this.btnTres.Text = "Quantidade de Par na frases";
            this.btnTres.UseVisualStyleBackColor = true;
            // 
            // rtbPrincipal
            // 
            this.rtbPrincipal.Location = new System.Drawing.Point(18, 19);
            this.rtbPrincipal.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rtbPrincipal.Name = "rtbPrincipal";
            this.rtbPrincipal.Size = new System.Drawing.Size(372, 153);
            this.rtbPrincipal.TabIndex = 3;
            this.rtbPrincipal.Text = "";
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(18, 321);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(372, 29);
            this.txtResultado.TabIndex = 4;
            // 
            // FrmExercicio01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 386);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.rtbPrincipal);
            this.Controls.Add(this.btnTres);
            this.Controls.Add(this.btnDois);
            this.Controls.Add(this.btnUm);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmExercicio01";
            this.Text = "FrmExercicio01";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUm;
        private System.Windows.Forms.Button btnDois;
        private System.Windows.Forms.Button btnTres;
        private System.Windows.Forms.RichTextBox rtbPrincipal;
        private System.Windows.Forms.TextBox txtResultado;
    }
}