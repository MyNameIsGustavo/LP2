﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void btnUm_Click(object sender, EventArgs e)
        {   int x;
            int y = 0;

        for (x = 0; x < rtbPrincipal.Text.Length; x++)
        {
            if (char.IsWhiteSpace(rtbPrincipal.Text[x]))
            {
                y ++;    
            }
        }
        txtResultado.Text = y.ToString();
        }
    }
}
