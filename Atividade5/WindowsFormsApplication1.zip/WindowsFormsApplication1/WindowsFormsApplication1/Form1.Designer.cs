﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVerificadorDesconto = new System.Windows.Forms.Button();
            this.lblColaborador = new System.Windows.Forms.Label();
            this.lblSalBruto = new System.Windows.Forms.Label();
            this.lblNumFilhos = new System.Windows.Forms.Label();
            this.lblINSS = new System.Windows.Forms.Label();
            this.lblIRPF = new System.Windows.Forms.Label();
            this.lblSalFamilia = new System.Windows.Forms.Label();
            this.lblSalLiquido = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.cbmbxNumFilhos = new System.Windows.Forms.ComboBox();
            this.grpbxSexo = new System.Windows.Forms.GroupBox();
            this.tbtnFeminino = new System.Windows.Forms.RadioButton();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.chkbxCasado = new System.Windows.Forms.CheckBox();
            this.lbltexto = new System.Windows.Forms.Label();
            this.txtColaborador = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.mskbxAliqINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliqIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescIRPF = new System.Windows.Forms.MaskedTextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.mskbxSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.grpbxSexo.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnVerificadorDesconto
            // 
            this.btnVerificadorDesconto.Location = new System.Drawing.Point(27, 247);
            this.btnVerificadorDesconto.Name = "btnVerificadorDesconto";
            this.btnVerificadorDesconto.Size = new System.Drawing.Size(597, 41);
            this.btnVerificadorDesconto.TabIndex = 0;
            this.btnVerificadorDesconto.Text = "Verificar desconto!";
            this.btnVerificadorDesconto.UseVisualStyleBackColor = true;
            this.btnVerificadorDesconto.Click += new System.EventHandler(this.btnVerificadorDesconto_Click);
            // 
            // lblColaborador
            // 
            this.lblColaborador.AutoSize = true;
            this.lblColaborador.Location = new System.Drawing.Point(28, 19);
            this.lblColaborador.Name = "lblColaborador";
            this.lblColaborador.Size = new System.Drawing.Size(144, 17);
            this.lblColaborador.TabIndex = 1;
            this.lblColaborador.Text = "Nome do colaborador:";
            // 
            // lblSalBruto
            // 
            this.lblSalBruto.AutoSize = true;
            this.lblSalBruto.Location = new System.Drawing.Point(28, 94);
            this.lblSalBruto.Name = "lblSalBruto";
            this.lblSalBruto.Size = new System.Drawing.Size(87, 17);
            this.lblSalBruto.TabIndex = 2;
            this.lblSalBruto.Text = "Salario bruto:";
            // 
            // lblNumFilhos
            // 
            this.lblNumFilhos.AutoSize = true;
            this.lblNumFilhos.Location = new System.Drawing.Point(31, 165);
            this.lblNumFilhos.Name = "lblNumFilhos";
            this.lblNumFilhos.Size = new System.Drawing.Size(113, 17);
            this.lblNumFilhos.TabIndex = 3;
            this.lblNumFilhos.Text = "Número de filhos:";
            // 
            // lblINSS
            // 
            this.lblINSS.AutoSize = true;
            this.lblINSS.Location = new System.Drawing.Point(31, 370);
            this.lblINSS.Name = "lblINSS";
            this.lblINSS.Size = new System.Drawing.Size(90, 17);
            this.lblINSS.TabIndex = 4;
            this.lblINSS.Text = "Aliquota INSS:";
            // 
            // lblIRPF
            // 
            this.lblIRPF.AutoSize = true;
            this.lblIRPF.Location = new System.Drawing.Point(28, 437);
            this.lblIRPF.Name = "lblIRPF";
            this.lblIRPF.Size = new System.Drawing.Size(87, 17);
            this.lblIRPF.TabIndex = 5;
            this.lblIRPF.Text = "Aliquota IRPF:";
            // 
            // lblSalFamilia
            // 
            this.lblSalFamilia.AutoSize = true;
            this.lblSalFamilia.Location = new System.Drawing.Point(28, 498);
            this.lblSalFamilia.Name = "lblSalFamilia";
            this.lblSalFamilia.Size = new System.Drawing.Size(93, 17);
            this.lblSalFamilia.TabIndex = 6;
            this.lblSalFamilia.Text = "Salario familia:";
            // 
            // lblSalLiquido
            // 
            this.lblSalLiquido.AutoSize = true;
            this.lblSalLiquido.Location = new System.Drawing.Point(28, 559);
            this.lblSalLiquido.Name = "lblSalLiquido";
            this.lblSalLiquido.Size = new System.Drawing.Size(95, 17);
            this.lblSalLiquido.TabIndex = 7;
            this.lblSalLiquido.Text = "Salario liquido:";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(373, 428);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(97, 17);
            this.lblDescINSS.TabIndex = 8;
            this.lblDescINSS.Text = "Desconto INSS:";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(373, 501);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(94, 17);
            this.lblDescIRPF.TabIndex = 9;
            this.lblDescIRPF.Text = "Desconto IRPF:";
            // 
            // cbmbxNumFilhos
            // 
            this.cbmbxNumFilhos.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbmbxNumFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbmbxNumFilhos.Location = new System.Drawing.Point(149, 162);
            this.cbmbxNumFilhos.Name = "cbmbxNumFilhos";
            this.cbmbxNumFilhos.Size = new System.Drawing.Size(227, 25);
            this.cbmbxNumFilhos.TabIndex = 10;
            // 
            // grpbxSexo
            // 
            this.grpbxSexo.Controls.Add(this.tbtnFeminino);
            this.grpbxSexo.Controls.Add(this.rbtnMasculino);
            this.grpbxSexo.Location = new System.Drawing.Point(424, 16);
            this.grpbxSexo.Name = "grpbxSexo";
            this.grpbxSexo.Size = new System.Drawing.Size(200, 100);
            this.grpbxSexo.TabIndex = 11;
            this.grpbxSexo.TabStop = false;
            this.grpbxSexo.Text = "Sexo:";
            // 
            // tbtnFeminino
            // 
            this.tbtnFeminino.AutoSize = true;
            this.tbtnFeminino.Location = new System.Drawing.Point(21, 63);
            this.tbtnFeminino.Name = "tbtnFeminino";
            this.tbtnFeminino.Size = new System.Drawing.Size(78, 21);
            this.tbtnFeminino.TabIndex = 1;
            this.tbtnFeminino.Text = "Feminino";
            this.tbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Location = new System.Drawing.Point(21, 24);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(85, 21);
            this.rbtnMasculino.TabIndex = 0;
            this.rbtnMasculino.Text = "Masculino";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // chkbxCasado
            // 
            this.chkbxCasado.AutoSize = true;
            this.chkbxCasado.Location = new System.Drawing.Point(21, 40);
            this.chkbxCasado.Name = "chkbxCasado";
            this.chkbxCasado.Size = new System.Drawing.Size(71, 21);
            this.chkbxCasado.TabIndex = 12;
            this.chkbxCasado.Text = "Casado";
            this.chkbxCasado.UseVisualStyleBackColor = true;
            // 
            // lbltexto
            // 
            this.lbltexto.AutoSize = true;
            this.lbltexto.Location = new System.Drawing.Point(303, 291);
            this.lbltexto.Name = "lbltexto";
            this.lbltexto.Size = new System.Drawing.Size(50, 17);
            this.lbltexto.TabIndex = 13;
            this.lbltexto.Text = "label10";
            // 
            // txtColaborador
            // 
            this.txtColaborador.Location = new System.Drawing.Point(178, 16);
            this.txtColaborador.Name = "txtColaborador";
            this.txtColaborador.Size = new System.Drawing.Size(198, 25);
            this.txtColaborador.TabIndex = 14;
            this.txtColaborador.Validated += new System.EventHandler(this.txtColaborador_Validated);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(178, 629);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(323, 78);
            this.button1.TabIndex = 22;
            this.button1.Text = "Limpar dados!";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // mskbxAliqINSS
            // 
            this.mskbxAliqINSS.Location = new System.Drawing.Point(127, 367);
            this.mskbxAliqINSS.Name = "mskbxAliqINSS";
            this.mskbxAliqINSS.Size = new System.Drawing.Size(205, 25);
            this.mskbxAliqINSS.TabIndex = 23;
            // 
            // mskbxAliqIRPF
            // 
            this.mskbxAliqIRPF.Location = new System.Drawing.Point(127, 434);
            this.mskbxAliqIRPF.Name = "mskbxAliqIRPF";
            this.mskbxAliqIRPF.Size = new System.Drawing.Size(205, 25);
            this.mskbxAliqIRPF.TabIndex = 24;
            // 
            // mskbxSalFamilia
            // 
            this.mskbxSalFamilia.Location = new System.Drawing.Point(127, 495);
            this.mskbxSalFamilia.Name = "mskbxSalFamilia";
            this.mskbxSalFamilia.Size = new System.Drawing.Size(205, 25);
            this.mskbxSalFamilia.TabIndex = 25;
            // 
            // mskbxSalLiquido
            // 
            this.mskbxSalLiquido.Location = new System.Drawing.Point(129, 556);
            this.mskbxSalLiquido.Name = "mskbxSalLiquido";
            this.mskbxSalLiquido.Size = new System.Drawing.Size(203, 25);
            this.mskbxSalLiquido.TabIndex = 26;
            // 
            // mskbxDescINSS
            // 
            this.mskbxDescINSS.Location = new System.Drawing.Point(476, 425);
            this.mskbxDescINSS.Name = "mskbxDescINSS";
            this.mskbxDescINSS.Size = new System.Drawing.Size(150, 25);
            this.mskbxDescINSS.TabIndex = 27;
            // 
            // mskbxDescIRPF
            // 
            this.mskbxDescIRPF.Location = new System.Drawing.Point(473, 495);
            this.mskbxDescIRPF.Name = "mskbxDescIRPF";
            this.mskbxDescIRPF.Size = new System.Drawing.Size(153, 25);
            this.mskbxDescIRPF.TabIndex = 28;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chkbxCasado);
            this.panel1.Location = new System.Drawing.Point(424, 122);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(200, 100);
            this.panel1.TabIndex = 29;
            // 
            // mskbxSalBruto
            // 
            this.mskbxSalBruto.Location = new System.Drawing.Point(120, 91);
            this.mskbxSalBruto.Name = "mskbxSalBruto";
            this.mskbxSalBruto.Size = new System.Drawing.Size(256, 25);
            this.mskbxSalBruto.TabIndex = 30;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(657, 757);
            this.Controls.Add(this.mskbxSalBruto);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.mskbxDescIRPF);
            this.Controls.Add(this.mskbxDescINSS);
            this.Controls.Add(this.mskbxSalLiquido);
            this.Controls.Add(this.mskbxSalFamilia);
            this.Controls.Add(this.mskbxAliqIRPF);
            this.Controls.Add(this.mskbxAliqINSS);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txtColaborador);
            this.Controls.Add(this.lbltexto);
            this.Controls.Add(this.grpbxSexo);
            this.Controls.Add(this.cbmbxNumFilhos);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalLiquido);
            this.Controls.Add(this.lblSalFamilia);
            this.Controls.Add(this.lblIRPF);
            this.Controls.Add(this.lblINSS);
            this.Controls.Add(this.lblNumFilhos);
            this.Controls.Add(this.lblSalBruto);
            this.Controls.Add(this.lblColaborador);
            this.Controls.Add(this.btnVerificadorDesconto);
            this.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "Salarios";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpbxSexo.ResumeLayout(false);
            this.grpbxSexo.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVerificadorDesconto;
        private System.Windows.Forms.Label lblColaborador;
        private System.Windows.Forms.Label lblSalBruto;
        private System.Windows.Forms.Label lblNumFilhos;
        private System.Windows.Forms.Label lblINSS;
        private System.Windows.Forms.Label lblIRPF;
        private System.Windows.Forms.Label lblSalFamilia;
        private System.Windows.Forms.Label lblSalLiquido;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.ComboBox cbmbxNumFilhos;
        private System.Windows.Forms.GroupBox grpbxSexo;
        private System.Windows.Forms.RadioButton tbtnFeminino;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.CheckBox chkbxCasado;
        private System.Windows.Forms.Label lbltexto;
        private System.Windows.Forms.TextBox txtColaborador;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.MaskedTextBox mskbxAliqINSS;
        private System.Windows.Forms.MaskedTextBox mskbxAliqIRPF;
        private System.Windows.Forms.MaskedTextBox mskbxSalFamilia;
        private System.Windows.Forms.MaskedTextBox mskbxSalLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxDescINSS;
        private System.Windows.Forms.MaskedTextBox mskbxDescIRPF;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.MaskedTextBox mskbxSalBruto;
    }
}

