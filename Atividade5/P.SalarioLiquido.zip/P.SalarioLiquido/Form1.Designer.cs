﻿
namespace P.SalarioLiquido
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblMensagem = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.textAliquotaInss = new System.Windows.Forms.TextBox();
            this.textAliquotaIr = new System.Windows.Forms.TextBox();
            this.textSalLiquido = new System.Windows.Forms.TextBox();
            this.textDescontoInss = new System.Windows.Forms.TextBox();
            this.textDescontoIr = new System.Windows.Forms.TextBox();
            this.textSalFam = new System.Windows.Forms.TextBox();
            this.textBoxNomFunc = new System.Windows.Forms.TextBox();
            this.maskedTextSalBruto = new System.Windows.Forms.MaskedTextBox();
            this.radioButtonHomem = new System.Windows.Forms.RadioButton();
            this.radioButtonMulher = new System.Windows.Forms.RadioButton();
            this.comboBoxNumFilhos = new System.Windows.Forms.ComboBox();
            this.buttonVerificarDados = new System.Windows.Forms.Button();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.checkBoxCasado = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(72, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nome do Funcionário:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(72, 115);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Salário Bruto:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(72, 179);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Número de Filhos:";
            // 
            // lblMensagem
            // 
            this.lblMensagem.AutoSize = true;
            this.lblMensagem.Location = new System.Drawing.Point(72, 258);
            this.lblMensagem.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblMensagem.Name = "lblMensagem";
            this.lblMensagem.Size = new System.Drawing.Size(57, 16);
            this.lblMensagem.TabIndex = 3;
            this.lblMensagem.Text = "Dados:";
            this.lblMensagem.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(73, 387);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Alíquota INSS:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(80, 450);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(87, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Alíquota IR:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(73, 512);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Salário Líquido:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(573, 387);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(116, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Desconto INSS:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(579, 453);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(96, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Desconto IR:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(573, 512);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(116, 16);
            this.label10.TabIndex = 9;
            this.label10.Text = "Salário Família:";
            // 
            // textAliquotaInss
            // 
            this.textAliquotaInss.Enabled = false;
            this.textAliquotaInss.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textAliquotaInss.Location = new System.Drawing.Point(212, 383);
            this.textAliquotaInss.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textAliquotaInss.Name = "textAliquotaInss";
            this.textAliquotaInss.Size = new System.Drawing.Size(248, 21);
            this.textAliquotaInss.TabIndex = 10;
            // 
            // textAliquotaIr
            // 
            this.textAliquotaIr.Enabled = false;
            this.textAliquotaIr.Location = new System.Drawing.Point(212, 447);
            this.textAliquotaIr.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textAliquotaIr.Name = "textAliquotaIr";
            this.textAliquotaIr.Size = new System.Drawing.Size(248, 22);
            this.textAliquotaIr.TabIndex = 11;
            // 
            // textSalLiquido
            // 
            this.textSalLiquido.Enabled = false;
            this.textSalLiquido.Location = new System.Drawing.Point(212, 509);
            this.textSalLiquido.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textSalLiquido.Name = "textSalLiquido";
            this.textSalLiquido.Size = new System.Drawing.Size(248, 22);
            this.textSalLiquido.TabIndex = 12;
            // 
            // textDescontoInss
            // 
            this.textDescontoInss.Enabled = false;
            this.textDescontoInss.Location = new System.Drawing.Point(708, 384);
            this.textDescontoInss.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textDescontoInss.Name = "textDescontoInss";
            this.textDescontoInss.Size = new System.Drawing.Size(248, 22);
            this.textDescontoInss.TabIndex = 13;
            // 
            // textDescontoIr
            // 
            this.textDescontoIr.Enabled = false;
            this.textDescontoIr.Location = new System.Drawing.Point(708, 448);
            this.textDescontoIr.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textDescontoIr.Name = "textDescontoIr";
            this.textDescontoIr.Size = new System.Drawing.Size(248, 22);
            this.textDescontoIr.TabIndex = 14;
            // 
            // textSalFam
            // 
            this.textSalFam.Enabled = false;
            this.textSalFam.Location = new System.Drawing.Point(708, 509);
            this.textSalFam.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textSalFam.Name = "textSalFam";
            this.textSalFam.Size = new System.Drawing.Size(248, 22);
            this.textSalFam.TabIndex = 15;
            // 
            // textBoxNomFunc
            // 
            this.textBoxNomFunc.Location = new System.Drawing.Point(248, 45);
            this.textBoxNomFunc.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.textBoxNomFunc.Name = "textBoxNomFunc";
            this.textBoxNomFunc.Size = new System.Drawing.Size(248, 22);
            this.textBoxNomFunc.TabIndex = 16;
            // 
            // maskedTextSalBruto
            // 
            this.maskedTextSalBruto.Location = new System.Drawing.Point(248, 111);
            this.maskedTextSalBruto.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.maskedTextSalBruto.Mask = "0000.00";
            this.maskedTextSalBruto.Name = "maskedTextSalBruto";
            this.maskedTextSalBruto.Size = new System.Drawing.Size(248, 22);
            this.maskedTextSalBruto.TabIndex = 17;
            // 
            // radioButtonHomem
            // 
            this.radioButtonHomem.AutoSize = true;
            this.radioButtonHomem.Location = new System.Drawing.Point(3, 41);
            this.radioButtonHomem.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButtonHomem.Name = "radioButtonHomem";
            this.radioButtonHomem.Size = new System.Drawing.Size(78, 20);
            this.radioButtonHomem.TabIndex = 18;
            this.radioButtonHomem.Text = "Homem";
            this.radioButtonHomem.UseVisualStyleBackColor = true;
            // 
            // radioButtonMulher
            // 
            this.radioButtonMulher.AutoSize = true;
            this.radioButtonMulher.Checked = true;
            this.radioButtonMulher.Location = new System.Drawing.Point(3, 90);
            this.radioButtonMulher.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.radioButtonMulher.Name = "radioButtonMulher";
            this.radioButtonMulher.Size = new System.Drawing.Size(71, 20);
            this.radioButtonMulher.TabIndex = 19;
            this.radioButtonMulher.TabStop = true;
            this.radioButtonMulher.Text = "Mulher";
            this.radioButtonMulher.UseVisualStyleBackColor = true;
            // 
            // comboBoxNumFilhos
            // 
            this.comboBoxNumFilhos.FormattingEnabled = true;
            this.comboBoxNumFilhos.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12",
            "13",
            "14",
            "15",
            "16",
            "17",
            "18",
            "19",
            "20"});
            this.comboBoxNumFilhos.Location = new System.Drawing.Point(248, 176);
            this.comboBoxNumFilhos.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.comboBoxNumFilhos.Name = "comboBoxNumFilhos";
            this.comboBoxNumFilhos.Size = new System.Drawing.Size(248, 24);
            this.comboBoxNumFilhos.TabIndex = 20;
            // 
            // buttonVerificarDados
            // 
            this.buttonVerificarDados.Location = new System.Drawing.Point(494, 258);
            this.buttonVerificarDados.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonVerificarDados.Name = "buttonVerificarDados";
            this.buttonVerificarDados.Size = new System.Drawing.Size(242, 74);
            this.buttonVerificarDados.TabIndex = 21;
            this.buttonVerificarDados.Text = "Verificar Dados";
            this.buttonVerificarDados.UseVisualStyleBackColor = true;
            this.buttonVerificarDados.Click += new System.EventHandler(this.buttonVerificarDados_Click);
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Location = new System.Drawing.Point(753, 258);
            this.buttonLimpar.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(242, 74);
            this.buttonLimpar.TabIndex = 22;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.Click += new System.EventHandler(this.buttonLimpar_Click);
            // 
            // checkBoxCasado
            // 
            this.checkBoxCasado.AutoSize = true;
            this.checkBoxCasado.Location = new System.Drawing.Point(782, 198);
            this.checkBoxCasado.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.checkBoxCasado.Name = "checkBoxCasado";
            this.checkBoxCasado.Size = new System.Drawing.Size(99, 20);
            this.checkBoxCasado.TabIndex = 23;
            this.checkBoxCasado.Text = "Casado(a)";
            this.checkBoxCasado.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radioButtonHomem);
            this.groupBox1.Controls.Add(this.radioButtonMulher);
            this.groupBox1.Location = new System.Drawing.Point(778, 58);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.groupBox1.Size = new System.Drawing.Size(231, 118);
            this.groupBox1.TabIndex = 24;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Sexo:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1620, 787);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.checkBoxCasado);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.buttonVerificarDados);
            this.Controls.Add(this.comboBoxNumFilhos);
            this.Controls.Add(this.maskedTextSalBruto);
            this.Controls.Add(this.textBoxNomFunc);
            this.Controls.Add(this.textSalFam);
            this.Controls.Add(this.textDescontoIr);
            this.Controls.Add(this.textDescontoInss);
            this.Controls.Add(this.textSalLiquido);
            this.Controls.Add(this.textAliquotaIr);
            this.Controls.Add(this.textAliquotaInss);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblMensagem);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblMensagem;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textAliquotaInss;
        private System.Windows.Forms.TextBox textAliquotaIr;
        private System.Windows.Forms.TextBox textSalLiquido;
        private System.Windows.Forms.TextBox textDescontoInss;
        private System.Windows.Forms.TextBox textDescontoIr;
        private System.Windows.Forms.TextBox textSalFam;
        private System.Windows.Forms.TextBox textBoxNomFunc;
        private System.Windows.Forms.MaskedTextBox maskedTextSalBruto;
        private System.Windows.Forms.RadioButton radioButtonHomem;
        private System.Windows.Forms.RadioButton radioButtonMulher;
        private System.Windows.Forms.ComboBox comboBoxNumFilhos;
        private System.Windows.Forms.Button buttonVerificarDados;
        private System.Windows.Forms.Button buttonLimpar;
        private System.Windows.Forms.CheckBox checkBoxCasado;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

