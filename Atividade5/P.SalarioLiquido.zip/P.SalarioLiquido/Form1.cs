﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace P.SalarioLiquido
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonLimpar_Click(object sender, EventArgs e)
        {
            //Limpar as informãções para nova consulta//

            textBoxNomFunc.Clear();
            maskedTextSalBruto.Clear();
            textAliquotaInss.Clear();
            textAliquotaIr.Clear();
            textDescontoInss.Clear();
            textDescontoIr.Clear();
            textSalFam.Clear();
            textSalLiquido.Clear();
            lblMensagem.Text = "";
            comboBoxNumFilhos.Text = "";

        }
        
        private void buttonVerificarDados_Click(object sender, EventArgs e)
        {
            
                this.lblMensagem.Visible = true;

                double salarioBruto = 0;

            if ((textBoxNomFunc.Text == "") || (textBoxNomFunc.Text.Length < 4))
                MessageBox.Show("Nome inválido");
            else if (!double.TryParse(maskedTextSalBruto.Text, out salarioBruto))
                MessageBox.Show("Salário inválido");
            else
            {
                double descontoInss = 0;
                double descontoIr = 0;
                double salarioFamilia = 0;
                double salarioLiquido = 0;
                {
                    // Cálculo da Alíquota do INSS

                    if (salarioBruto <= 800.47)
                    {
                        textAliquotaInss.Text = "7.65%";
                        descontoInss = 0.0765 * salarioBruto;
                    }
                    else if (salarioBruto <= 1050)
                    {
                        textAliquotaInss.Text = "8.65%";
                        descontoInss = 0.0865 * salarioBruto;
                    }
                    else if (salarioBruto <= 1400.77)
                    {
                        textAliquotaInss.Text = "9%";
                        descontoInss = 0.09 * salarioBruto;
                    }
                    else if (salarioBruto <= 2801.56)
                    {
                        textAliquotaInss.Text = "11%";
                        descontoInss = 0.11 * salarioBruto;
                    }
                    else
                    {
                        descontoInss = 308.17;
                        
                    }
                    textDescontoInss.Text = descontoInss.ToString("N2");

                    // Cálculo da Aliquota do IR

                  if (salarioBruto <= 1257.12)
                    {
                        textAliquotaIr.Text = "Isento";
                        descontoIr = 0;
                    }
                  else if (salarioBruto <= 2512.08)
                    {
                        textAliquotaIr.Text = "15%";
                        descontoIr = 0.15 * salarioBruto;
                    }
                  else
                    {
                        textAliquotaIr.Text = "27.5%";
                        descontoIr = 0.275 * salarioBruto;
                    }

                    textDescontoIr.Text = descontoIr.ToString("N2");
            

                    // Cálculo do Salário Família 

                    if (salarioBruto <= 435.52)
                    {
                        textSalFam.Text = "22.33";
                        salarioFamilia = Convert.ToDouble(comboBoxNumFilhos.SelectedItem) * 22.33;
                    }
                    else if (salarioBruto <= 654.61)
                    {
                        textSalFam.Text = "15.74";
                        salarioFamilia = Convert.ToDouble(comboBoxNumFilhos.SelectedItem) * 15.74;
                    }
                    else
                    {
                        salarioFamilia = 0;
                    }

                    textSalFam.Text = salarioFamilia.ToString("N2");

                    salarioLiquido = salarioBruto - descontoInss - descontoIr + salarioFamilia;
                    textSalLiquido.Text = salarioLiquido.ToString("N2");

                    // LBL dos Dados

                    string texto = "Os descontos do Salário Bruto ";

                    if (radioButtonMulher.Checked)
                    {
                        texto = texto + "da Sra." + textBoxNomFunc.Text + "\n";
                    }
                    else
                    {
                        texto = texto + "do Sr. " + textBoxNomFunc.Text + "\n";
                    }

                    if (checkBoxCasado.Checked)
                    {
                        texto = texto + " que é Casado(a)";
                        texto = texto + " e que tem " + comboBoxNumFilhos.Text.ToString() + " filho(s) são: ";
                    }
                    else
                    {
                        texto = texto + " que é Solteiro(a)";
                        texto = texto + " e que tem " + comboBoxNumFilhos.Text.ToString() + " filho(s) são: ";
                    }


                    this.lblMensagem.Text = texto;

                }
            
            }
        }

    }
}