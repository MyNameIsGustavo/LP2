﻿namespace PFerramenta
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.lblNomeCarlos = new System.Windows.Forms.Label();
            this.lblNomeGustavo = new System.Windows.Forms.Label();
            this.lblNomeMatheus = new System.Windows.Forms.Label();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.imltFotos = new System.Windows.Forms.ImageList(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.txtTextoCarlos = new System.Windows.Forms.Label();
            this.txtTextoGustavo = new System.Windows.Forms.Label();
            this.txtTextoGustavo2 = new System.Windows.Forms.Label();
            this.txtTextoCarlos2 = new System.Windows.Forms.Label();
            this.txtTextoMatheus = new System.Windows.Forms.Label();
            this.txtTextoMatheus2 = new System.Windows.Forms.Label();
            this.txtTextoMatheus3 = new System.Windows.Forms.Label();
            this.lblRAMatheus = new System.Windows.Forms.Label();
            this.lblRAGustavo = new System.Windows.Forms.Label();
            this.lblRACarlos = new System.Windows.Forms.Label();
            this.txtTextoCarlos3 = new System.Windows.Forms.Label();
            this.lblObrigado = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblNomeCarlos
            // 
            this.lblNomeCarlos.AutoSize = true;
            this.lblNomeCarlos.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeCarlos.Location = new System.Drawing.Point(98, 91);
            this.lblNomeCarlos.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNomeCarlos.Name = "lblNomeCarlos";
            this.lblNomeCarlos.Size = new System.Drawing.Size(128, 21);
            this.lblNomeCarlos.TabIndex = 0;
            this.lblNomeCarlos.Text = "Carlos Eduardo";
            // 
            // lblNomeGustavo
            // 
            this.lblNomeGustavo.AutoSize = true;
            this.lblNomeGustavo.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeGustavo.Location = new System.Drawing.Point(498, 91);
            this.lblNomeGustavo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNomeGustavo.Name = "lblNomeGustavo";
            this.lblNomeGustavo.Size = new System.Drawing.Size(127, 21);
            this.lblNomeGustavo.TabIndex = 1;
            this.lblNomeGustavo.Text = "Gustavo Rocha";
            // 
            // lblNomeMatheus
            // 
            this.lblNomeMatheus.AutoSize = true;
            this.lblNomeMatheus.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomeMatheus.Location = new System.Drawing.Point(916, 91);
            this.lblNomeMatheus.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblNomeMatheus.Name = "lblNomeMatheus";
            this.lblNomeMatheus.Size = new System.Drawing.Size(128, 21);
            this.lblNomeMatheus.TabIndex = 2;
            this.lblNomeMatheus.Text = "Matheus Favara";
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(454, 30);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(229, 23);
            this.lblTitulo.TabIndex = 3;
            this.lblTitulo.Text = "Criadores dessa aplicação:";
            // 
            // imltFotos
            // 
            this.imltFotos.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imltFotos.ImageStream")));
            this.imltFotos.TransparentColor = System.Drawing.Color.Transparent;
            this.imltFotos.Images.SetKeyName(0, "Matzo.jpeg");
            this.imltFotos.Images.SetKeyName(1, "Calvo.jpeg");
            this.imltFotos.Images.SetKeyName(2, "tijolo.jpeg");
            // 
            // button1
            // 
            this.button1.ImageIndex = 0;
            this.button1.ImageList = this.imltFotos;
            this.button1.Location = new System.Drawing.Point(896, 137);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 164);
            this.button1.TabIndex = 4;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.ImageIndex = 1;
            this.button2.ImageList = this.imltFotos;
            this.button2.Location = new System.Drawing.Point(480, 137);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(166, 164);
            this.button2.TabIndex = 5;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.ImageIndex = 2;
            this.button3.ImageList = this.imltFotos;
            this.button3.Location = new System.Drawing.Point(75, 137);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(166, 164);
            this.button3.TabIndex = 6;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // txtTextoCarlos
            // 
            this.txtTextoCarlos.AutoSize = true;
            this.txtTextoCarlos.Location = new System.Drawing.Point(85, 312);
            this.txtTextoCarlos.Name = "txtTextoCarlos";
            this.txtTextoCarlos.Size = new System.Drawing.Size(141, 21);
            this.txtTextoCarlos.TabIndex = 7;
            this.txtTextoCarlos.Text = "MyNameIsCarlão";
            // 
            // txtTextoGustavo
            // 
            this.txtTextoGustavo.AutoSize = true;
            this.txtTextoGustavo.Location = new System.Drawing.Point(357, 312);
            this.txtTextoGustavo.Name = "txtTextoGustavo";
            this.txtTextoGustavo.Size = new System.Drawing.Size(434, 21);
            this.txtTextoGustavo.TabIndex = 8;
            this.txtTextoGustavo.Text = "Muito obrigado por todos os ensinamentos, professora! ";
            // 
            // txtTextoGustavo2
            // 
            this.txtTextoGustavo2.AutoSize = true;
            this.txtTextoGustavo2.Location = new System.Drawing.Point(328, 333);
            this.txtTextoGustavo2.Name = "txtTextoGustavo2";
            this.txtTextoGustavo2.Size = new System.Drawing.Size(477, 21);
            this.txtTextoGustavo2.TabIndex = 9;
            this.txtTextoGustavo2.Text = "Até a próxima! Me desculpa pelos meninos. Eles são malucos.";
            // 
            // txtTextoCarlos2
            // 
            this.txtTextoCarlos2.AutoSize = true;
            this.txtTextoCarlos2.Location = new System.Drawing.Point(32, 333);
            this.txtTextoCarlos2.Name = "txtTextoCarlos2";
            this.txtTextoCarlos2.Size = new System.Drawing.Size(265, 21);
            this.txtTextoCarlos2.TabIndex = 10;
            this.txtTextoCarlos2.Text = " you speack inglish from teh strets";
            // 
            // txtTextoMatheus
            // 
            this.txtTextoMatheus.AutoSize = true;
            this.txtTextoMatheus.Location = new System.Drawing.Point(881, 312);
            this.txtTextoMatheus.Name = "txtTextoMatheus";
            this.txtTextoMatheus.Size = new System.Drawing.Size(181, 21);
            this.txtTextoMatheus.TabIndex = 11;
            this.txtTextoMatheus.Text = "its me matso, o grando";
            // 
            // txtTextoMatheus2
            // 
            this.txtTextoMatheus2.AutoSize = true;
            this.txtTextoMatheus2.Location = new System.Drawing.Point(850, 333);
            this.txtTextoMatheus2.Name = "txtTextoMatheus2";
            this.txtTextoMatheus2.Size = new System.Drawing.Size(249, 21);
            this.txtTextoMatheus2.TabIndex = 12;
            this.txtTextoMatheus2.Text = "o rocha é calvo e o carlão treme";
            // 
            // txtTextoMatheus3
            // 
            this.txtTextoMatheus3.AutoSize = true;
            this.txtTextoMatheus3.Location = new System.Drawing.Point(916, 354);
            this.txtTextoMatheus3.Name = "txtTextoMatheus3";
            this.txtTextoMatheus3.Size = new System.Drawing.Size(113, 21);
            this.txtTextoMatheus3.TabIndex = 13;
            this.txtTextoMatheus3.Text = "Finishi finishi ";
            // 
            // lblRAMatheus
            // 
            this.lblRAMatheus.AutoSize = true;
            this.lblRAMatheus.Location = new System.Drawing.Point(916, 113);
            this.lblRAMatheus.Name = "lblRAMatheus";
            this.lblRAMatheus.Size = new System.Drawing.Size(127, 21);
            this.lblRAMatheus.TabIndex = 14;
            this.lblRAMatheus.Text = "0030482121030";
            // 
            // lblRAGustavo
            // 
            this.lblRAGustavo.AutoSize = true;
            this.lblRAGustavo.Location = new System.Drawing.Point(498, 113);
            this.lblRAGustavo.Name = "lblRAGustavo";
            this.lblRAGustavo.Size = new System.Drawing.Size(127, 21);
            this.lblRAGustavo.TabIndex = 15;
            this.lblRAGustavo.Text = "0030482121034";
            // 
            // lblRACarlos
            // 
            this.lblRACarlos.AutoSize = true;
            this.lblRACarlos.Location = new System.Drawing.Point(99, 113);
            this.lblRACarlos.Name = "lblRACarlos";
            this.lblRACarlos.Size = new System.Drawing.Size(127, 21);
            this.lblRACarlos.TabIndex = 16;
            this.lblRACarlos.Text = "0030482121014";
            // 
            // txtTextoCarlos3
            // 
            this.txtTextoCarlos3.AutoSize = true;
            this.txtTextoCarlos3.Location = new System.Drawing.Point(104, 354);
            this.txtTextoCarlos3.Name = "txtTextoCarlos3";
            this.txtTextoCarlos3.Size = new System.Drawing.Size(96, 21);
            this.txtTextoCarlos3.TabIndex = 17;
            this.txtTextoCarlos3.Text = "My Good!!";
            // 
            // lblObrigado
            // 
            this.lblObrigado.AutoSize = true;
            this.lblObrigado.Font = new System.Drawing.Font("Times New Roman", 20.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblObrigado.Location = new System.Drawing.Point(486, 455);
            this.lblObrigado.Name = "lblObrigado";
            this.lblObrigado.Size = new System.Drawing.Size(169, 31);
            this.lblObrigado.TabIndex = 18;
            this.lblObrigado.Text = "OBRIGADO!!";
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1185, 548);
            this.Controls.Add(this.lblObrigado);
            this.Controls.Add(this.txtTextoCarlos3);
            this.Controls.Add(this.lblRACarlos);
            this.Controls.Add(this.lblRAGustavo);
            this.Controls.Add(this.lblRAMatheus);
            this.Controls.Add(this.txtTextoMatheus3);
            this.Controls.Add(this.txtTextoMatheus2);
            this.Controls.Add(this.txtTextoMatheus);
            this.Controls.Add(this.txtTextoCarlos2);
            this.Controls.Add(this.txtTextoGustavo2);
            this.Controls.Add(this.txtTextoGustavo);
            this.Controls.Add(this.txtTextoCarlos);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.lblNomeMatheus);
            this.Controls.Add(this.lblNomeGustavo);
            this.Controls.Add(this.lblNomeCarlos);
            this.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNomeCarlos;
        private System.Windows.Forms.Label lblNomeGustavo;
        private System.Windows.Forms.Label lblNomeMatheus;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.ImageList imltFotos;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label txtTextoCarlos;
        private System.Windows.Forms.Label txtTextoGustavo;
        private System.Windows.Forms.Label txtTextoGustavo2;
        private System.Windows.Forms.Label txtTextoCarlos2;
        private System.Windows.Forms.Label txtTextoMatheus;
        private System.Windows.Forms.Label txtTextoMatheus2;
        private System.Windows.Forms.Label txtTextoMatheus3;
        private System.Windows.Forms.Label lblRAMatheus;
        private System.Windows.Forms.Label lblRAGustavo;
        private System.Windows.Forms.Label lblRACarlos;
        private System.Windows.Forms.Label txtTextoCarlos3;
        private System.Windows.Forms.Label lblObrigado;
    }
}