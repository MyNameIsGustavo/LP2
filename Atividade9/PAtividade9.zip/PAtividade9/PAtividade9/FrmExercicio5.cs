﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAtividade9
{
    public partial class FrmExercicio5 : Form
    {
        public FrmExercicio5()
        {
            InitializeComponent();
        }

        private void btnExe_Click(object sender, EventArgs e)
        {
            double[,] matrizNotas = new double[20, 3];
            string auxiliar = "";
            double media = 0;

            for (var i = 0; i < 20; i++)
            {
                media = 0;
                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Digite a nota", "Entrada das notas");
                    if (double.TryParse(auxiliar, out matrizNotas[i, j]))
                    {
                        if ((matrizNotas[i, j] > 0) || (matrizNotas[i, j] <= 10))
                        {
                            MessageBox.Show("Nota inválida");
                            j--;
                        }
                        else
                        {
                            media += matrizNotas[i, j];
                        }
                    }
                    else{
                        MessageBox.Show("Nota inválida");
                        j--;
                    }                        
                    
                }
                media = media / 3;
                lstNotas.Items.Add("Aluno:" + (i + 1) + "Média:" + media.ToString("N2"));
            }
        }
    }
}
