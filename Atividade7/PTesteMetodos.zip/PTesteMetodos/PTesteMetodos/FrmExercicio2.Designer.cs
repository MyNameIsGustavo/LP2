﻿namespace PTesteMetodos
{
    partial class FrmExercicio2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPalavraUm = new System.Windows.Forms.Label();
            this.lblPalavraDois = new System.Windows.Forms.Label();
            this.txtPalavraUm = new System.Windows.Forms.TextBox();
            this.txtPalavraDois = new System.Windows.Forms.TextBox();
            this.btnIguais = new System.Windows.Forms.Button();
            this.btnTxtUmTxtDois = new System.Windows.Forms.Button();
            this.btnAster = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblPalavraUm
            // 
            this.lblPalavraUm.AutoSize = true;
            this.lblPalavraUm.Location = new System.Drawing.Point(33, 28);
            this.lblPalavraUm.Name = "lblPalavraUm";
            this.lblPalavraUm.Size = new System.Drawing.Size(52, 13);
            this.lblPalavraUm.TabIndex = 0;
            this.lblPalavraUm.Text = "Palavra1:";
            // 
            // lblPalavraDois
            // 
            this.lblPalavraDois.AutoSize = true;
            this.lblPalavraDois.Location = new System.Drawing.Point(36, 69);
            this.lblPalavraDois.Name = "lblPalavraDois";
            this.lblPalavraDois.Size = new System.Drawing.Size(52, 13);
            this.lblPalavraDois.TabIndex = 1;
            this.lblPalavraDois.Text = "Palavra2:";
            // 
            // txtPalavraUm
            // 
            this.txtPalavraUm.Location = new System.Drawing.Point(104, 28);
            this.txtPalavraUm.Name = "txtPalavraUm";
            this.txtPalavraUm.Size = new System.Drawing.Size(100, 20);
            this.txtPalavraUm.TabIndex = 2;
            // 
            // txtPalavraDois
            // 
            this.txtPalavraDois.Location = new System.Drawing.Point(104, 69);
            this.txtPalavraDois.Name = "txtPalavraDois";
            this.txtPalavraDois.Size = new System.Drawing.Size(100, 20);
            this.txtPalavraDois.TabIndex = 3;
            // 
            // btnIguais
            // 
            this.btnIguais.Location = new System.Drawing.Point(18, 114);
            this.btnIguais.Name = "btnIguais";
            this.btnIguais.Size = new System.Drawing.Size(89, 59);
            this.btnIguais.TabIndex = 4;
            this.btnIguais.Text = "Testar iguais";
            this.btnIguais.UseVisualStyleBackColor = true;
            this.btnIguais.Click += new System.EventHandler(this.btnIguais_Click);
            // 
            // btnTxtUmTxtDois
            // 
            this.btnTxtUmTxtDois.Location = new System.Drawing.Point(132, 114);
            this.btnTxtUmTxtDois.Name = "btnTxtUmTxtDois";
            this.btnTxtUmTxtDois.Size = new System.Drawing.Size(91, 59);
            this.btnTxtUmTxtDois.TabIndex = 5;
            this.btnTxtUmTxtDois.Text = "Inserir texto 1 no texto 2";
            this.btnTxtUmTxtDois.UseVisualStyleBackColor = true;
            this.btnTxtUmTxtDois.Click += new System.EventHandler(this.btnTxtUmTxtDois_Click);
            // 
            // btnAster
            // 
            this.btnAster.Location = new System.Drawing.Point(255, 114);
            this.btnAster.Name = "btnAster";
            this.btnAster.Size = new System.Drawing.Size(117, 59);
            this.btnAster.TabIndex = 6;
            this.btnAster.Text = "Inserir asteristicos no texto 1";
            this.btnAster.UseVisualStyleBackColor = true;
            this.btnAster.Click += new System.EventHandler(this.btnAster_Click);
            // 
            // FrmExercicio2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(512, 541);
            this.Controls.Add(this.btnAster);
            this.Controls.Add(this.btnTxtUmTxtDois);
            this.Controls.Add(this.btnIguais);
            this.Controls.Add(this.txtPalavraDois);
            this.Controls.Add(this.txtPalavraUm);
            this.Controls.Add(this.lblPalavraDois);
            this.Controls.Add(this.lblPalavraUm);
            this.Name = "FrmExercicio2";
            this.Text = "FrmExercicio2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPalavraUm;
        private System.Windows.Forms.Label lblPalavraDois;
        private System.Windows.Forms.TextBox txtPalavraUm;
        private System.Windows.Forms.TextBox txtPalavraDois;
        private System.Windows.Forms.Button btnIguais;
        private System.Windows.Forms.Button btnTxtUmTxtDois;
        private System.Windows.Forms.Button btnAster;
    }
}