﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class FrmExercicio2 : Form
    {
        public FrmExercicio2()
        {
            InitializeComponent();
        }

        private void btnIguais_Click(object sender, EventArgs e)
        {
            if (String.Compare(txtPalavraUm.Text, txtPalavraDois.Text, true) == 0)
                MessageBox.Show("São iguais");
            else
                MessageBox.Show("São diferentes!");
        }

        private void btnTxtUmTxtDois_Click(object sender, EventArgs e)
        {
            int meio = txtPalavraDois.Text.Length / 2;

            txtPalavraDois.Text = txtPalavraDois.Text.Substring(0, meio)
                + txtPalavraUm.Text + txtPalavraDois.Text.Substring(meio, 
                txtPalavraDois.Text.Length - meio);
        }

        private void btnAster_Click(object sender, EventArgs e)
        {
            int meio = txtPalavraUm.Text.Length / 2;
            txtPalavraUm.Text = txtPalavraUm.Text.Insert(meio, "**");
        }

    }
}
