﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class FrmExercicio3 : Form
    {
        public FrmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemoveOcorre_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            txtpalavraum.Text = txtpalavraum.Text.ToUpper();
            txtpalavradois.Text = txtpalavradois.Text.ToUpper();

            posicao = txtpalavradois.Text.IndexOf(txtpalavraum.Text);

            while(posicao >= 0)
            {
                txtpalavradois.Text = txtpalavradois.Text.Substring(0, posicao) +
                    txtpalavradois.Text.Substring(posicao + txtpalavraum.Text.Length, 
                        txtpalavradois.Text.Length - posicao - txtpalavraum.Text.Length);

                posicao = txtpalavradois.Text.IndexOf(txtpalavraum.Text);
            }

        }

        private void btnReplace_Click(object sender, EventArgs e)
        {
            txtpalavraum.Text = txtpalavraum.Text.ToUpper();
            txtpalavradois.Text = txtpalavradois.Text.ToUpper();

            txtpalavradois.Text = txtpalavradois.Text.Replace(txtpalavraum.Text, "");
        }

        private void btnReverse_Click(object sender, EventArgs e)
        {
            string auxiliar = txtpalavraum.Text;

            char[] arr = auxiliar.ToCharArray();
            Array.Reverse(arr);

            auxiliar = "";

            foreach(char cara in arr)
            {
                auxiliar = auxiliar + cara.ToString();
            }

            MessageBox.Show(auxiliar);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtpalavraum.Clear();
            txtpalavradois.Clear();
        }
    }
}
