﻿namespace PTesteMetodos
{
    partial class FrmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReverse = new System.Windows.Forms.Button();
            this.btnReplace = new System.Windows.Forms.Button();
            this.btnRemoveOcorre = new System.Windows.Forms.Button();
            this.txtpalavradois = new System.Windows.Forms.TextBox();
            this.txtpalavraum = new System.Windows.Forms.TextBox();
            this.lblpalavradois = new System.Windows.Forms.Label();
            this.lblpalavraum = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnReverse
            // 
            this.btnReverse.Location = new System.Drawing.Point(12, 196);
            this.btnReverse.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnReverse.Name = "btnReverse";
            this.btnReverse.Size = new System.Drawing.Size(315, 40);
            this.btnReverse.TabIndex = 15;
            this.btnReverse.Text = "Inverte (REVERSE)";
            this.btnReverse.UseVisualStyleBackColor = true;
            this.btnReverse.Click += new System.EventHandler(this.btnReverse_Click);
            // 
            // btnReplace
            // 
            this.btnReplace.Location = new System.Drawing.Point(12, 144);
            this.btnReplace.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnReplace.Name = "btnReplace";
            this.btnReplace.Size = new System.Drawing.Size(315, 42);
            this.btnReplace.TabIndex = 14;
            this.btnReplace.Text = "Remove Ocorrencias (REPLACE)";
            this.btnReplace.UseVisualStyleBackColor = true;
            this.btnReplace.Click += new System.EventHandler(this.btnReplace_Click);
            // 
            // btnRemoveOcorre
            // 
            this.btnRemoveOcorre.Location = new System.Drawing.Point(12, 93);
            this.btnRemoveOcorre.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btnRemoveOcorre.Name = "btnRemoveOcorre";
            this.btnRemoveOcorre.Size = new System.Drawing.Size(315, 41);
            this.btnRemoveOcorre.TabIndex = 13;
            this.btnRemoveOcorre.Text = "Remove Ocorrencias";
            this.btnRemoveOcorre.UseVisualStyleBackColor = true;
            this.btnRemoveOcorre.Click += new System.EventHandler(this.btnRemoveOcorre_Click);
            // 
            // txtpalavradois
            // 
            this.txtpalavradois.Location = new System.Drawing.Point(95, 48);
            this.txtpalavradois.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtpalavradois.Name = "txtpalavradois";
            this.txtpalavradois.Size = new System.Drawing.Size(230, 29);
            this.txtpalavradois.TabIndex = 12;
            // 
            // txtpalavraum
            // 
            this.txtpalavraum.Location = new System.Drawing.Point(95, 9);
            this.txtpalavraum.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtpalavraum.Name = "txtpalavraum";
            this.txtpalavraum.Size = new System.Drawing.Size(230, 29);
            this.txtpalavraum.TabIndex = 11;
            // 
            // lblpalavradois
            // 
            this.lblpalavradois.AutoSize = true;
            this.lblpalavradois.Location = new System.Drawing.Point(8, 53);
            this.lblpalavradois.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpalavradois.Name = "lblpalavradois";
            this.lblpalavradois.Size = new System.Drawing.Size(73, 21);
            this.lblpalavradois.TabIndex = 10;
            this.lblpalavradois.Text = "Palavra 2";
            // 
            // lblpalavraum
            // 
            this.lblpalavraum.AutoSize = true;
            this.lblpalavraum.Location = new System.Drawing.Point(8, 14);
            this.lblpalavraum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblpalavraum.Name = "lblpalavraum";
            this.lblpalavraum.Size = new System.Drawing.Size(73, 21);
            this.lblpalavraum.TabIndex = 9;
            this.lblpalavraum.Text = "Palavra 1";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(12, 244);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(313, 42);
            this.btnLimpar.TabIndex = 16;
            this.btnLimpar.Text = "Limpar Dados";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // FrmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(608, 612);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnReverse);
            this.Controls.Add(this.btnReplace);
            this.Controls.Add(this.btnRemoveOcorre);
            this.Controls.Add(this.txtpalavradois);
            this.Controls.Add(this.txtpalavraum);
            this.Controls.Add(this.lblpalavradois);
            this.Controls.Add(this.lblpalavraum);
            this.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "FrmExercicio3";
            this.Text = "FrmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReverse;
        private System.Windows.Forms.Button btnReplace;
        private System.Windows.Forms.Button btnRemoveOcorre;
        private System.Windows.Forms.TextBox txtpalavradois;
        private System.Windows.Forms.TextBox txtpalavraum;
        private System.Windows.Forms.Label lblpalavradois;
        private System.Windows.Forms.Label lblpalavraum;
        private System.Windows.Forms.Button btnLimpar;
    }
}