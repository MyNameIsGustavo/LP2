﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class Form1 : Form
    {
        int l, c;
        int num;
        String verificarGol, verificarTim, verificarGolRec;

        public Form1()
        {
            InitializeComponent();
        }

        private void lsbPrincipal_SelectedIndexChanged(object sender, EventArgs e)
        {
     
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            Double Ptn1, Ptn2, Ptn3, Ptn4, Ptn5, Ptn6,
                    Ptn7, Ptn8, Ptn9, Ptn10, Ptn11, Ptn12;

            double[,] TabelaGols = new double[l, c];

            for (c = 0; c < 4; c++)
            {
                for (l = 0; l < 3; l++)
                {

                    verificarTim = Interaction.InputBox("Entre com o nome do seu time: ");
                    verificarGol = Interaction.InputBox(" Entre com o número de gols: ");
                    verificarGolRec = Interaction.InputBox(" Entre com o número de gols Recebidos: ");
                }
            }
        }
        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
